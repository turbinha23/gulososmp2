package pt.gulosos.claims;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Lista TAB: tag para todos; FOUNDER/ADMIN com nome animado no estilo escolhido em /estilo. */
public class TabTask extends BukkitRunnable {

    private final Map<UUID, Component> cache = new HashMap<>();
    private final EstiloManager estilos;
    private int tick = 0;

    public TabTask() {
        this.estilos = new EstiloManager(JavaPlugin.getProvidingPlugin(TabTask.class));
    }

    @Override
    public void run() {
        tick++;
        estilos.animate(tick);
        for (Player p : Bukkit.getOnlinePlayers()) {
            int role = PlayerListener.roleIndex(p);
            String name = p.getName();
            Component styled;
            if (role == 0 || role == 1) {
                styled = estilos.effective(p, role).render(name, tick);
            } else {
                styled = Component.text(name);
            }
            Component full = PlayerListener.tagComponent(role).append(Component.text("")).append(styled);
            if (!full.equals(cache.get(p.getUniqueId()))) {
                p.playerListName(full);
                cache.put(p.getUniqueId(), full);
            }
        }
        if (tick % 200 == 0) {
            cache.keySet().removeIf(id -> Bukkit.getPlayer(id) == null);
        }
    }
}
