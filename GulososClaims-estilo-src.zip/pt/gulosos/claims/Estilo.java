package pt.gulosos.claims;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextColor;
import org.bukkit.Material;

import java.util.concurrent.ThreadLocalRandom;

/** Estilos animados do nome na lista TAB (so FOUNDER e ADMIN). */
public enum Estilo {
    HACKER("hacker", "Hacker", Material.COMMAND_BLOCK, "Codigo verde com falhas (o estilo ADMIN original)."),
    TERMINAL("terminal", "Terminal", Material.REPEATING_COMMAND_BLOCK, "O teu nome escrito num terminal, com cursor."),
    MATRIX("matrix", "Matrix", Material.EMERALD, "Chuva de codigo a atravessar o nome."),
    GLITCH("glitch", "Glitch", Material.REDSTONE, "Letras a falhar com cores de erro."),
    OURO("ouro", "Ouro", Material.GOLD_INGOT, "Dourado com brilho a passar (o estilo FOUNDER original)."),
    NEON("neon", "Neon", Material.AMETHYST_SHARD, "Ciano e magenta a deslizar."),
    FOGO("fogo", "Fogo", Material.BLAZE_POWDER, "Chamas a tremer do vermelho ao amarelo."),
    GELO("gelo", "Gelo", Material.ICE, "Azul gelado com reflexos brancos."),
    ARCOIRIS("arcoiris", "Arco-iris", Material.PRISMARINE_SHARD, "Todas as cores a rodar.");

    public final String id;
    public final String label;
    public final Material icon;
    public final String desc;

    Estilo(String id, String label, Material icon, String desc) {
        this.id = id;
        this.label = label;
        this.icon = icon;
        this.desc = desc;
    }

    public static Estilo byId(String id) {
        if (id == null) return null;
        for (Estilo e : values()) if (e.id.equalsIgnoreCase(id)) return e;
        return null;
    }

    private static final String GL = "01#$%&@*<>/\\|=+";

    public Component render(String name, int tick) {
        int len = Math.max(1, name.length());
        switch (this) {
            case HACKER: {
                double glitch = (tick / 5) % 12 == 0 ? 0.28 : 0.0;
                return NameStyle.admin(name, glitch, -tick * 0.02, false);
            }
            case OURO: {
                double shine = (tick * 0.45) % (name.length() + 10) - 3.0;
                return NameStyle.founder(name, tick * 0.015, shine);
            }
            case TERMINAL: {
                int t = (tick / 2) % (len + 10);
                int shown = Math.min(t, name.length());
                boolean on = t < name.length() || (tick / 3) % 2 == 0;
                Component out = ch("> ", 0x00A83A);
                out = out.append(ch(name.substring(0, shown), 0x00FF41));
                out = out.append(ch(on ? "_" : " ", 0xFFFFFF));
                return out;
            }
            case MATRIX: {
                double head = (tick * 0.7) % (len + 7) - 1;
                Component out = Component.empty();
                for (int i = 0; i < name.length(); i++) {
                    double d = head - i;
                    int rgb;
                    if (d < 0) rgb = 0x006B1F;
                    else if (d < 1) rgb = 0xE0FFE0;
                    else rgb = mix(0x00FF41, 0x006B1F, Math.min(1.0, (d - 1) / 5.0));
                    out = out.append(ch(String.valueOf(name.charAt(i)), rgb));
                }
                return out;
            }
            case GLITCH: {
                ThreadLocalRandom r = ThreadLocalRandom.current();
                boolean burst = (tick / 4) % 7 == 0;
                Component out = Component.empty();
                for (int i = 0; i < name.length(); i++) {
                    if (burst && r.nextDouble() < 0.4) {
                        String g = String.valueOf(GL.charAt(r.nextInt(GL.length())));
                        out = out.append(ch(g, r.nextBoolean() ? 0xFF0055 : 0x00E5FF));
                    } else {
                        out = out.append(ch(String.valueOf(name.charAt(i)), 0xEDEDED));
                    }
                }
                return out;
            }
            case NEON: {
                Component out = Component.empty();
                for (int i = 0; i < name.length(); i++) {
                    double p = (i / (double) len + tick * 0.03) % 1.0;
                    double t = 1.0 - Math.abs(2.0 * p - 1.0);
                    out = out.append(ch(String.valueOf(name.charAt(i)), mix(0x00F0FF, 0xFF2BD6, t)));
                }
                return out;
            }
            case FOGO: {
                ThreadLocalRandom r = ThreadLocalRandom.current();
                int[] stops = {0xFF1A00, 0xFF8800, 0xFFE100};
                Component out = Component.empty();
                for (int i = 0; i < name.length(); i++) {
                    double v = 0.5 + 0.5 * Math.sin(tick * 0.6 + i * 0.8) + (r.nextDouble() - 0.5) * 0.25;
                    out = out.append(ch(String.valueOf(name.charAt(i)), grad(stops, v)));
                }
                return out;
            }
            case GELO: {
                int[] stops = {0x2A9DFF, 0x9BE7FF, 0xFFFFFF};
                Component out = Component.empty();
                for (int i = 0; i < name.length(); i++) {
                    double v = 0.5 + 0.5 * Math.sin(tick * 0.2 - i * 0.6);
                    out = out.append(ch(String.valueOf(name.charAt(i)), grad(stops, v)));
                }
                return out;
            }
            default: { // ARCOIRIS
                Component out = Component.empty();
                for (int i = 0; i < name.length(); i++) {
                    double h = ((i / (double) len) * 0.8 + tick * 0.02) % 1.0;
                    out = out.append(ch(String.valueOf(name.charAt(i)), hsv(h, 0.85, 1.0)));
                }
                return out;
            }
        }
    }

    private static Component ch(String s, int rgb) {
        return Component.text(s, TextColor.color(rgb));
    }

    private static int mix(int a, int b, double t) {
        t = Math.max(0.0, Math.min(1.0, t));
        int r = (int) Math.round(((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) Math.round(((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) Math.round((a & 255) * (1 - t) + (b & 255) * t);
        return (r << 16) | (g << 8) | bl;
    }

    private static int grad(int[] stops, double t) {
        t = Math.max(0.0, Math.min(1.0, t));
        double s = t * (stops.length - 1);
        int i = (int) Math.floor(s);
        if (i >= stops.length - 1) return stops[stops.length - 1];
        return mix(stops[i], stops[i + 1], s - i);
    }

    private static int hsv(double h, double s, double v) {
        double x = h * 6.0;
        int hi = ((int) Math.floor(x)) % 6;
        double f = x - Math.floor(x);
        double p = v * (1 - s), q = v * (1 - f * s), t = v * (1 - (1 - f) * s);
        double r, g, b;
        switch (hi) {
            case 0: r = v; g = t; b = p; break;
            case 1: r = q; g = v; b = p; break;
            case 2: r = p; g = v; b = t; break;
            case 3: r = p; g = q; b = v; break;
            case 4: r = t; g = p; b = v; break;
            default: r = v; g = p; b = q; break;
        }
        return ((int) Math.round(r * 255) << 16) | ((int) Math.round(g * 255) << 8) | (int) Math.round(b * 255);
    }
}
