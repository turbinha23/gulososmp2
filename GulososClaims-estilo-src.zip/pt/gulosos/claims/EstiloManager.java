package pt.gulosos.claims;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

/** /estilo: menu para FOUNDER e ADMIN escolherem o estilo animado do nome no TAB. */
public final class EstiloManager implements CommandExecutor, TabCompleter, Listener {

    public static final class Holder implements InventoryHolder {
        private Inventory inv;
        @Override public Inventory getInventory() { return inv; }
    }

    private static final int RESET_SLOT = 22;
    private static final int FIRST_SLOT = 9;

    private final JavaPlugin plugin;
    private final File file;
    private final YamlConfiguration data;
    private final Set<UUID> viewers = new HashSet<>();
    private int tick;

    public EstiloManager(JavaPlugin plugin) {
        this.plugin = plugin;
        plugin.getDataFolder().mkdirs();
        this.file = new File(plugin.getDataFolder(), "estilos.yml");
        this.data = YamlConfiguration.loadConfiguration(file);

        plugin.getServer().getPluginManager().registerEvents(this, plugin);
        PluginCommand cmd = plugin.getCommand("estilo");
        if (cmd != null) {
            cmd.setExecutor(this);
            cmd.setTabCompleter(this);
        }
    }

    // ---------- dados ----------

    public static boolean allowed(Player p) {
        int r = PlayerListener.roleIndex(p);
        return r == 0 || r == 1;
    }

    /** Estilo escolhido, ou o padrao do cargo (FOUNDER=ouro, ADMIN=hacker). */
    public Estilo effective(Player p, int role) {
        Estilo e = Estilo.byId(data.getString(p.getUniqueId().toString()));
        if (e != null) return e;
        return role == 0 ? Estilo.OURO : Estilo.HACKER;
    }

    private void store(UUID id, Estilo e) {
        data.set(id.toString(), e == null ? null : e.id);
        try {
            data.save(file);
        } catch (IOException ex) {
            // ignorado: a escolha continua em memoria
        }
    }

    // ---------- comando ----------

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage(Component.text("So jogadores podem usar /estilo.", NamedTextColor.RED));
            return true;
        }
        if (!allowed(p)) {
            say(p, "Este comando e so para FOUNDER e ADMIN.", NamedTextColor.RED);
            return true;
        }
        if (args.length == 0) {
            open(p);
            return true;
        }
        String a = args[0].toLowerCase(Locale.ROOT);
        if (a.equals("reset") || a.equals("padrao")) {
            reset(p);
            return true;
        }
        Estilo e = Estilo.byId(a);
        if (e == null) {
            StringBuilder sb = new StringBuilder();
            for (Estilo s : Estilo.values()) sb.append(sb.length() == 0 ? "" : ", ").append(s.id);
            say(p, "Estilo desconhecido. Disponiveis: " + sb + ", reset", NamedTextColor.YELLOW);
            return true;
        }
        choose(p, e);
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
        List<String> out = new ArrayList<>();
        if (!(sender instanceof Player p) || !allowed(p) || args.length != 1) return out;
        String pre = args[0].toLowerCase(Locale.ROOT);
        for (Estilo e : Estilo.values()) if (e.id.startsWith(pre)) out.add(e.id);
        if ("reset".startsWith(pre)) out.add("reset");
        return out;
    }

    private void choose(Player p, Estilo e) {
        store(p.getUniqueId(), e);
        Component msg = Component.text("[Estilo] ", NamedTextColor.GRAY)
                .append(Component.text("Estilo ativo: ", NamedTextColor.GREEN))
                .append(e.render(p.getName(), tick));
        p.sendMessage(msg);
        refresh(p);
    }

    private void reset(Player p) {
        store(p.getUniqueId(), null);
        say(p, "Estilo reposto para o padrao do teu cargo.", NamedTextColor.GREEN);
        refresh(p);
    }

    private void say(Player p, String text, TextColor color) {
        p.sendMessage(Component.text("[Estilo] ", NamedTextColor.GRAY).append(Component.text(text, color)));
    }

    // ---------- menu ----------

    public void open(Player p) {
        Holder h = new Holder();
        Inventory inv = Bukkit.createInventory(h, 27, Component.text("Estilos do TAB", TextColor.color(0x00FF41)));
        h.inv = inv;
        fill(inv, p);
        p.openInventory(inv);
        viewers.add(p.getUniqueId()); // depois do open (o open fecha o menu anterior)
    }

    private void refresh(Player p) {
        if (!viewers.contains(p.getUniqueId())) return;
        Inventory top = p.getOpenInventory().getTopInventory();
        if (top.getHolder() instanceof Holder) fill(top, p);
    }

    /** Chamado pelo TabTask: anima as pre-visualizacoes dos menus abertos. */
    public void animate(int tick) {
        this.tick = tick;
        if (viewers.isEmpty()) return;
        for (UUID id : new ArrayList<>(viewers)) {
            Player p = Bukkit.getPlayer(id);
            if (p == null) { viewers.remove(id); continue; }
            Inventory top = p.getOpenInventory().getTopInventory();
            if (top.getHolder() instanceof Holder) fill(top, p);
            else viewers.remove(id);
        }
    }

    private void fill(Inventory inv, Player p) {
        Estilo cur = effective(p, PlayerListener.roleIndex(p));
        ItemStack pane = plain(Material.BLACK_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < 27; i++) inv.setItem(i, pane);

        ItemStack info = plain(Material.PAPER, "Escolhe o teu estilo");
        ItemMeta im = info.getItemMeta();
        List<Component> il = new ArrayList<>();
        il.add(noItalic(Component.text("Animacao do teu nome na lista TAB.", NamedTextColor.GRAY)));
        il.add(noItalic(Component.text("So FOUNDER e ADMIN veem isto.", NamedTextColor.DARK_GRAY)));
        im.lore(il);
        info.setItemMeta(im);
        inv.setItem(4, info);

        for (Estilo e : Estilo.values()) {
            inv.setItem(FIRST_SLOT + e.ordinal(), styleItem(e, p.getName(), e == cur));
        }
        inv.setItem(RESET_SLOT, plain(Material.BARRIER, "Repor padrao do cargo"));
    }

    private ItemStack styleItem(Estilo e, String name, boolean selected) {
        ItemStack it = new ItemStack(e.icon);
        ItemMeta m = it.getItemMeta();
        m.displayName(noItalic(Component.text(e.label, selected ? NamedTextColor.GREEN : NamedTextColor.WHITE)));
        List<Component> lore = new ArrayList<>();
        lore.add(noItalic(Component.text(e.desc, NamedTextColor.GRAY)));
        lore.add(noItalic(Component.text(" ")));
        lore.add(noItalic(Component.text("Pre-visualizacao:", NamedTextColor.DARK_GRAY)));
        lore.add(noItalic(e.render(name, tick)));
        lore.add(noItalic(Component.text(" ")));
        lore.add(noItalic(selected
                ? Component.text("Selecionado", NamedTextColor.GREEN)
                : Component.text("Clica para escolher", NamedTextColor.YELLOW)));
        m.lore(lore);
        m.setEnchantmentGlintOverride(selected ? Boolean.TRUE : null);
        it.setItemMeta(m);
        return it;
    }

    private ItemStack plain(Material mat, String name) {
        ItemStack it = new ItemStack(mat);
        ItemMeta m = it.getItemMeta();
        m.displayName(noItalic(Component.text(name, NamedTextColor.WHITE)));
        it.setItemMeta(m);
        return it;
    }

    private static Component noItalic(Component c) {
        return Component.empty().decoration(TextDecoration.ITALIC, false).append(c);
    }

    // ---------- eventos ----------

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (!viewers.contains(p.getUniqueId())) return;
        if (!(e.getInventory().getHolder() instanceof Holder)) return;
        e.setCancelled(true);
        if (!allowed(p)) { p.closeInventory(); return; }
        int slot = e.getRawSlot();
        if (slot == RESET_SLOT) { reset(p); return; }
        for (Estilo s : Estilo.values()) {
            if (FIRST_SLOT + s.ordinal() == slot) { choose(p, s); return; }
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (viewers.contains(p.getUniqueId())) e.setCancelled(true);
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        viewers.remove(e.getPlayer().getUniqueId());
    }
}
